<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    // public function profile()
    // {

    //     // dd('ini halaman profile');
    //     return view('profile');
    // }
}


// meflush data login

// class UserController extends Controller
// {
//     public function profile(Request $request)
//     {
//         $request->session()->flush();
//         // dd('ini halaman profile');
//     }
// }
